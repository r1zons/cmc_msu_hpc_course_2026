import collections
import json
import os
from pathlib import Path
import socket
import sys


def bind(prefix, program):
    threads = int(os.environ["OMP_NUM_THREADS"])
    local_rank = int(os.environ["SLURM_LOCALID"])
    host = socket.gethostname().split(".")[0]
    rank = int(os.environ["SLURM_PROCID"])
    expected_host = "pg5" if rank < int(os.environ["STARLING_RANKS_PER_NODE"]) else "pg6"
    if host != expected_host:
        raise SystemExit(f"rank {rank}: expected {expected_host}, got {host}")
    affinity = sorted(os.sched_getaffinity(0))
    cores = {}
    for cpu in affinity:
        topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        core = tuple(int((topology / field).read_text())
                     for field in ("physical_package_id", "core_id"))
        cores.setdefault(core, cpu)
    socket_cores = sorted(core for core in cores if core[0] == local_rank % 2)
    offset = local_rank // 2 * threads
    if len(socket_cores) != 24 or offset + threads > 24:
        raise SystemExit(f"rank {rank}: expected whole socket in exclusive allocation; mask={affinity}")
    cores = {core: cores[core] for core in socket_cores[offset:offset + threads]}
    os.sched_setaffinity(0, cores.values())
    if os.sched_getaffinity(0) != set(cores.values()):
        raise SystemExit(f"rank {rank}: requested affinity not applied")
    with open(f"{prefix}.rank{rank}.json", "x") as output:
        json.dump(dict(host=host, local_rank=local_rank, cores=list(cores), cpus=list(cores.values())),
                  output)
    os.execv(program[0], program)


def check(prefix, ranks, threads, nodes):
    counts = collections.Counter()
    used = set()
    for rank in range(ranks):
        binding = json.loads(Path(f"{prefix}.rank{rank}.json").read_text())
        counts[binding["host"]] += 1
        keys = {(binding["host"], *core) for core in binding["cores"]}
        if len(keys) != threads or keys & used or {key[1] for key in keys} != {binding["local_rank"] % 2}:
            raise SystemExit(f"oversubscribed or incorrect physical-core mask at rank {rank}")
        used.update(keys)
    expected = sorted((ranks + i) // nodes for i in range(nodes))
    if sorted(counts.values()) != expected:
        raise SystemExit(f"wrong rank distribution: {counts}")
    data = dict(line.split("=", 1) for line in Path(f"{prefix}.stdout").read_text().splitlines()
                if "=" in line)
    if (data.get("mpi_ranks"), data.get("openmp_threads"), data.get("boundary_check")) != (
            str(ranks), str(threads), "passed"):
        raise SystemExit(f"wrong solver layout or boundary check: {data}")
    if "/pilot." in prefix and data.get("halo_check") != "passed":
        raise SystemExit("pilot halo check missing")


if sys.argv[1] == "--check":
    check(sys.argv[2], *map(int, sys.argv[3:]))
else:
    bind(sys.argv[1], sys.argv[2:])
