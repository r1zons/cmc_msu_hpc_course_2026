#!/bin/bash
set -euo pipefail
set -o noclobber
exec 3>"${1:-fixed-preflight-submissions.tsv}"
printf 'layout\tnodes\tjob_id\n' >&3
for nodes in 1 2; do
    ranks=$((nodes+1))
    hosts=pg5
    [[ $nodes == 1 ]] || hosts=pg5,pg6
    job=$(sbatch --parsable --partition=high --exclusive --mem=12G --time=00:05:00 \
        --nodes="$nodes" --nodelist="$hosts" --ntasks="$ranks" --ntasks-per-node=2 --cpus-per-task=10 \
        --hint=nomultithread --distribution=block:block --job-name="wave-fixed-preflight-${nodes}n" \
        --output=logs/pilot.%j.out --error=logs/pilot.%j.err job.sh pilot "$nodes" "$ranks" 10 "${ranks}x1x1")
    job=${job%%;*}
    [[ $job =~ ^[0-9]+$ ]]
    printf '%sx10\t%s\t%s\n' "$ranks" "$nodes" "$job" >&3
    printf '%sx10\t%s\t%s\n' "$ranks" "$nodes" "$job"
done
