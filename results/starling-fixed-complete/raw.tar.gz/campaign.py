import csv
from pathlib import Path
import subprocess
import sys


FIELDS = ("measurement_id", "ranks", "threads", "dims", "nodes",
          "n", "length", "steps", "cfl", "repetition")
PRIORITY = [(1, 1), (4, 1), (8, 1), (16, 1), (32, 1),
            (1, 4), (2, 4), (4, 4), (8, 4)]


def write_csv(path, fields, rows):
    with path.open("x", newline="") as output:
        writer = csv.writer(output)
        writer.writerow(fields)
        writer.writerows(rows)


def prepare(source):
    with open(source, newline="") as data:
        layouts = {}
        for row in csv.DictReader(data):
            key = int(row["ranks"]), int(row["threads"])
            placement = row["dims"], int(row["expected_nodes"])
            if layouts.setdefault(key, placement) != placement:
                raise ValueError(f"inconsistent historical layout for {key}")
    expected = {(ranks, cores // ranks)
                for cores in (1, 2, 4, 8, 16, 32)
                for ranks in (1, 2, 4, 8, 16, 32) if cores % ranks == 0 and cores // ranks <= 16}
    expected.update((ranks, 10) for ranks in range(1, 5))
    assert len(expected) == 24 and set(layouts) == expected
    Path("layouts").mkdir()
    Path("logs").mkdir(exist_ok=True)
    matrix = []
    jobs = []
    for ranks, threads in PRIORITY + sorted(expected - set(PRIORITY)):
        dims, nodes = layouts[ranks, threads]
        assert nodes == (2 if ranks * threads > 20 else 1)
        name = f"r{ranks}-t{threads}"
        rows = [(f"starling-{name}-n{n}-l{label}-rep{rep}", ranks, threads, dims, nodes,
                 n, length, 20, "0.5", rep)
                for n in (128, 256, 512)
                for label, length in (("1", "1"), ("pi", "3.1415926535897931"))
                for rep in range(1, 4)]
        write_csv(Path(f"layouts/{name}.csv"), FIELDS, rows)
        jobs.append((name, ranks, threads, nodes))
        matrix.extend(rows)
    assert len(matrix) == len({row[0] for row in matrix}) == 432
    write_csv(Path("manifest.csv"), FIELDS, matrix)
    write_csv(Path("arrays.csv"), ("layout", "ranks", "threads", "nodes"), jobs)


def submit(pilots):
    for pilot in pilots:
        if Path(f"logs/pilot.{int(pilot)}.status").read_text().strip() != "exit_status=0":
            raise SystemExit(f"preflight {pilot} did not pass")
    with open("arrays.csv", newline="") as descriptor, open("submissions.csv", "x", newline="") as ledger:
        writer = csv.writer(ledger)
        writer.writerow(("layout", "array_job_id", "task_ids", "status", "message"))
        previous = None
        for row in csv.DictReader(descriptor):
            name = row["layout"]
            ranks, threads, nodes = (int(row[key]) for key in ("ranks", "threads", "nodes"))
            hosts = "pg5" if nodes == 1 else "pg5,pg6"
            cmd = ["sbatch", "--parsable", "--partition=high", "--exclusive", "--mem=12G",
                   "--time=00:10:00", f"--nodes={nodes}", f"--ntasks={ranks}",
                   f"--nodelist={hosts}",
                   f"--ntasks-per-node={(ranks+nodes-1)//nodes}", f"--cpus-per-task={threads}",
                   "--hint=nomultithread", "--distribution=block:block",
                   "--array=0-17%2", f"--job-name=wave-{name}", "--output=logs/%A_%a.out",
                   "--error=logs/%A_%a.err"]
            if previous:
                cmd.append(f"--dependency=afterany:{previous}")
            result = subprocess.run(cmd + ["job.sh", name], stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, universal_newlines=True)
            job_id = result.stdout.strip().split(";")[0]
            if result.returncode or not job_id.isdigit():
                writer.writerow((name, "", "0-17", "not_confirmed", result.stderr.strip() or result.stdout.strip()))
                ledger.flush()
                raise SystemExit(f"submission stopped at {name}: {result.stderr or result.stdout}")
            previous = job_id
            writer.writerow((name, job_id, "0-17", "submitted", result.stderr.strip()))
            ledger.flush()
            print(name, job_id, flush=True)


if sys.argv[1] == "prepare":
    prepare(sys.argv[2])
elif sys.argv[1] == "submit" and len(sys.argv) == 4:
    submit(sys.argv[2:])
else:
    raise SystemExit("campaign.py prepare POLUS_CSV | submit SINGLE_PILOT MULTI_PILOT")
