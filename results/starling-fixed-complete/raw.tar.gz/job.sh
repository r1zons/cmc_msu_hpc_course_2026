#!/bin/bash
set -euo pipefail
export LC_ALL=C
cd "${SLURM_SUBMIT_DIR:?}"
source /usr/local/Modules/init/bash
module load mpi/mpich/4.3.0
sha256sum -c SHA256SUMS >&2

if [[ ${1:-} == pilot ]]; then
    shift
    nodes=$1
    ranks=$2
    threads=$3
    dims=$4
    n=128
    length=1
    verify=(--verify)
    prefix="logs/pilot.${SLURM_JOB_ID}"
    srun --mpi=none -N "$nodes" -n "$nodes" --ntasks-per-node=1 -l bash -c '
        hostname; lscpu; ls /sys/class/infiniband; ip -br link
        ls -d /sys/devices/system/node/node[0-9]*' >"$prefix.hardware"
else
    [[ ${1:?} =~ ^r[0-9]+-t[0-9]+$ ]]
    row=$(sed -n "$((SLURM_ARRAY_TASK_ID+2))p" "layouts/$1.csv")
    IFS=, read -r id ranks threads dims nodes n length steps cfl repetition <<< "$row"
    [[ -n $id && $steps == 20 && $cfl == 0.5 ]]
    verify=()
    prefix="logs/$id.${SLURM_JOB_ID}"
fi
[[ $nodes == "$SLURM_JOB_NUM_NODES" && $ranks == "$SLURM_NTASKS" && $threads == "$SLURM_CPUS_PER_TASK" ]]
expected_hosts=$'pg5'
[[ $nodes == 1 ]] || expected_hosts=$'pg5\npg6'
[[ $(scontrol show hostnames "$SLURM_JOB_NODELIST") == "$expected_hosts" ]]

export OMP_NUM_THREADS="$threads" OMP_DYNAMIC=FALSE OMP_PLACES=cores
export OMP_PROC_BIND=close OMP_DISPLAY_AFFINITY=TRUE
export STARLING_RANKS_PER_NODE=$(((ranks+nodes-1)/nodes))
printf 'job=%s nodes=%s nodelist=%s cpus_per_node=%s\n' "$SLURM_JOB_ID" "$nodes" "$SLURM_JOB_NODELIST" "$SLURM_JOB_CPUS_PER_NODE" >&2
set -o noclobber
status=0
env -u SLURM_CPUS_PER_TASK -u SLURM_TRES_PER_TASK -u SLURM_THREADS_PER_CORE -u SLURM_HINT \
    srun --mpi=pmi2 --ntasks="$ranks" \
    --ntasks-per-node="$STARLING_RANKS_PER_NODE" \
    --distribution=block:block --cpu-bind=verbose,none --kill-on-bad-exit=1 \
    python3 rank.py "$prefix" build/wave_solver_mpi --n "$n" --lx "$length" \
    --ly "$length" --lz "$length" --steps 20 --cfl 0.5 --threads "$threads" \
    --dims "$dims" "${verify[@]}" >"$prefix.stdout" || status=$?
if [[ $status == 0 ]]; then
    python3 rank.py --check "$prefix" "$ranks" "$threads" "$nodes" || status=$?
fi
printf 'exit_status=%s\n' "$status" >"$prefix.status"
exit "$status"
