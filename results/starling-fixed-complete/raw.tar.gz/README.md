# Starling: fixed-layout wave benchmark

The 24 rank × thread layouts, Cartesian grids, and one-/two-node counts
come from the validated POLUS manifest. This campaign has three rather
than ten independent allocations per layout, grid size, and domain length.
One-node jobs require pg5; two-node jobs require pg5 and pg6, with ranks
in contiguous blocks (3 ranks split 2+1, pg5 first). Within each node,
even local ranks use socket 0 and odd local ranks socket 1. Each rank
selects distinct physical cores with one hardware thread per core.
The 10-thread groups are not full sockets (24 physical cores per socket).

Slurm 25.05.0 exposes pg4–pg8, each with two 24-core sockets, SMT2 and
257563 MiB of schedulable RAM. Both partitions are exclusive: high defaults
to 15 minutes; low has a six-hour maximum. This workflow uses high,
12 GiB per node, five minutes for each pilot and ten per measurement.
Arrays are throttled and chained with afterany. Since every measurement
exclusively requires pg5, production measurements cannot overlap.

The bundled MPICH 4.3.0 advertises ch3/nemesis with a3ch and TCP; a
specific active inter-node fabric is not assumed. The pilot records node
models, NUMA topology and network devices, verifies the solver's discrete
mode and halos, and checks the physical CPU masks. Successful MPI
communication alone does not establish which transport was used.

Prepare in an empty output directory with
`python3 /path/to/campaign.py prepare /path/to/polus-fixed-complete/measurements.csv`.
Transfer the generated layouts and these workflow files to the frozen
build directory. From the frozen build directory run `bash preflight.sh`.
After inspecting both successful pilots and confirming the account permits
the pending arrays, run `python3 campaign.py submit SINGLE_NODE_ID TWO_NODE_ID`.
The exclusive-create ledgers prevent accidental submission of either group
twice. If a submission response is missing, reconcile with Slurm before
doing anything else. The per-layout CSV header is followed by rows in
array-index order starting at index 0.
