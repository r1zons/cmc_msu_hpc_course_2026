import csv,json,re,sys,shutil
from pathlib import Path
old,root=map(Path,sys.argv[1:])
keys={'1x2','1x4','1x8','1x10','2x2','2x4','2x8','2x10','3x10','4x2','4x4','4x8','4x10','8x2','8x4','16x2'}
def read(path):
    with path.open(newline='') as f: return list(csv.DictReader(f))
def write(path,rows):
    with path.open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
source=read(old/'manifest.csv')
rows=[dict(r,measurement_id='retry-'+r['measurement_id']) for r in source if r['ranks']+'x'+r['threads'] in keys]
assert len(rows)==len({r['measurement_id'] for r in rows})==960
root.mkdir()
for folder in ('jobs','logs','measurements','rankfiles','lsf-hostfiles'): (root/folder).mkdir()
shutil.copytree(old/'bin',root/'bin')
meta=json.loads((old/'metadata.json').read_text())
meta.update(manifest_rows=len(rows), replaces_campaign=str(old))
(root/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
write(root/'manifest.csv',rows)
write(root/'submissions.csv',[dict(measurement_id=r['measurement_id'],state='pending',job_id='',submitted_utc='',note='') for r in rows])
for key in keys:
    shutil.copy(old/'lsf-hostfiles'/key,root/'lsf-hostfiles'/key)
    lines=[]
    for line in (old/'rankfiles'/key).read_text().splitlines():
        prefix,slot=line.split(' slot=')
        socket,core=slot.split(':')
        nums=list(map(int,core.split(',')))
        assert nums==list(range(nums[0],nums[-1]+1))
        assert len(nums)==int(key.split('x')[1])
        lines.append(f'{prefix} slot={socket}:{nums[0]}-{nums[-1]}')
    (root/'rankfiles'/key).write_text('\n'.join(lines)+'\n')
pilots=[r['measurement_id'] for r in rows if r['n']=='128' and float(r['length'])==1 and r['repetition']=='1']
assert len(pilots)==16
(root/'pilot-ids.txt').write_text(','.join(pilots)+'\n')
