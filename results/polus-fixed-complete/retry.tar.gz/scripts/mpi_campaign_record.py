#!/usr/bin/env python3
"""Turn one completed solver stdout into a manifest-linked measurement row."""
import csv
import json
import os
import socket
import sys
from pathlib import Path

if len(sys.argv)!=19: raise SystemExit('internal usage error')
root,mid,job,hosts,mode,n,length,steps,tfinal,ranks,threads,dims,slots,nodes,queue,start,finish,out=sys.argv[1:]
values={}
for line in Path(out).read_text(errors='replace').splitlines():
    if '=' in line:
        k,v=line.split('=',1); values[k.strip()]=v.strip()
row={'measurement_id':mid,'status':'passed','mode':mode,'n':values.get('n',''),
     'length':values.get('lx',''),'steps':values.get('time_steps',''),
     'final_time':values.get('physical_final_time',''),'ranks':values.get('mpi_ranks',''),
     'threads':values.get('openmp_threads',''),'dims':values.get('process_grid',''),
     'expected_slots':slots,'job_id':job,'scheduler_queue':queue,'host_allocation':hosts,
     'expected_nodes':nodes,'actual_nodes':str(len(hosts.split())//2),
     'actual_slots':str(sum(int(x) for x in hosts.split()[1::2])),
     'hostname':socket.gethostname(),'start_utc':start,'finish_utc':finish,
     'runtime_environment':json.dumps({k:os.environ.get(k,'') for k in
       ('OMP_NUM_THREADS','OMP_PLACES','OMP_PROC_BIND','MPI_MAP_BY','MPIEXEC','MPI_SOLVER',
        'OMPI_MCA_pml','UCX_TLS','UCX_NET_DEVICES')},sort_keys=True),
     'stdout':Path(out).name}
for key in ('solve_wall_seconds','max_absolute_error','physical_final_time','mpi_ranks',
            'openmp_threads','process_grid','boundary_check','hosts','mpi_library'):
    if key in values: row[key]=values[key]
if values.get('boundary_check')!='passed': row['status']='failed'
path=Path(root)/'measurements'/(mid+'.'+job+'.csv')
with path.open('x',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(row)); w.writeheader(); w.writerow(row)
