#!/usr/bin/env python3
"""Validate new manifest-backed campaigns and retain legacy log summaries."""
import csv
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from mpi_campaign import analyze

def legacy(root):
    groups=defaultdict(list); errors=defaultdict(list)
    for path in sorted((Path(root)/'logs').glob('*/*.out')):
        try:
            values=dict(line.split('=',1) for line in path.read_text(errors='replace').splitlines() if '=' in line)
            if values.get('boundary_check')!='passed':
                print('ignored incomplete run: '+str(path),file=sys.stderr); continue
            model=path.parent.name.split('_')[0]
            key=(model,int(values['n']),float(values['lx']),values['physical_final_time'],
                 int(values['time_steps']),int(values['openmp_threads']),int(values['mpi_ranks']),values['process_grid'])
            elapsed=float(values['solve_wall_seconds']); error=float(values['max_absolute_error'])
            n,length,t,steps=key[1:5]
            theta=2*math.asin(0.5*math.sin(math.pi/(2*n)))
            expected=abs(math.cos(steps*theta)-math.cos(math.pi*math.sqrt(3)*float(t)/length))
            if not math.isfinite(elapsed) or elapsed<=0 or not math.isfinite(error) or \
                    abs(error-expected)>8*sys.float_info.epsilon*(steps+1)**2:
                print('ignored invalid measurement: '+str(path),file=sys.stderr); continue
            groups[key].append(elapsed); errors[key].append(error)
        except (KeyError,ValueError,OverflowError) as e:
            print('ignored malformed legacy run %s: %s'%(path,e),file=sys.stderr)
    writer=csv.writer(sys.stdout)
    writer.writerow(('mode','n','length','t','steps','threads','ranks','process_grid','reps',
                     'median_seconds','min_seconds','max_seconds','median_error','speedup'))
    for key,times in sorted(groups.items()):
        ref=groups.get((*key[:6],1,'1x1x1')); median=statistics.median(times)
        writer.writerow((*key,len(times),median,min(times),max(times),statistics.median(errors[key]),
                         statistics.median(ref)/median if ref else ''))
    if not groups: return 1
    return 0

if len(sys.argv) != 2:
    sys.exit('usage: analyze_mpi.py CAMPAIGN_DIRECTORY')
campaign=Path(sys.argv[1])
sys.exit(analyze(campaign) if (campaign/'manifest.csv').is_file() else legacy(campaign))
