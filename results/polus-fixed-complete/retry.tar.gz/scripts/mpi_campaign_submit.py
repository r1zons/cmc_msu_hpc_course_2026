#!/usr/bin/env python3
"""Explicit, bounded LSF campaign submission. Preparation itself never imports this."""
import argparse
import fcntl
import csv
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

FIELDS = ['measurement_id','mode','n','length','steps','final_time','cfl','ranks','threads',
          'dims','repetition','expected_nodes','expected_slots','expected_hosts']

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('campaign'); ap.add_argument('--plan',action='store_true')
    ap.add_argument('--submit-one',metavar='MEASUREMENT_ID')
    ap.add_argument('--submit-batch',action='store_true')
    ap.add_argument('--ids',help='comma-separated measurement IDs selected for --submit-batch')
    ap.add_argument('--repetition',type=int,help='select one repetition round for --submit-batch')
    ap.add_argument('--resolve',metavar='MEASUREMENT_ID',help='record a manual LSF reconciliation')
    ap.add_argument('--outcome',choices=['submitted','not-found'])
    ap.add_argument('--job-id')
    ap.add_argument('--max-jobs',type=int,default=0); ap.add_argument('--max-slots',type=int,default=0)
    ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args(); root=Path(a.campaign).resolve()
    if sum((a.plan,bool(a.submit_one),a.submit_batch,bool(a.resolve)))!=1: ap.error('choose --plan, --submit-one, --submit-batch, or --resolve')
    if not a.submit_batch and (a.ids or a.repetition is not None): ap.error('--ids and --repetition require --submit-batch')
    if not (a.plan or a.dry_run or a.resolve) and (a.max_jobs<1 or a.max_slots<1): ap.error('submission requires positive --max-jobs and --max-slots')
    with (root/'manifest.csv').open(newline='') as f: rows=list(csv.DictReader(f))
    if not rows or list(rows[0])!=FIELDS: raise SystemExit('manifest schema mismatch')
    if a.submit_batch:
        wanted=rows
        if a.repetition is not None: wanted=[r for r in wanted if int(r['repetition'])==a.repetition]
        if a.ids:
            selection=a.ids.split(','); selected=set(selection)
            if len(selected)!=len(selection): raise SystemExit('--ids contains repeated measurement IDs')
            wanted=[r for r in wanted if r['measurement_id'] in selected]
            if selected!={r['measurement_id'] for r in wanted}: raise SystemExit('--ids contains unknown or repeated measurement IDs')
        if not wanted: raise SystemExit('batch selection is empty')
    elif a.resolve: wanted=[]
    elif a.plan: wanted=rows
    else: wanted=[next((r for r in rows if r['measurement_id']==a.submit_one),None)]
    if any(r is None for r in wanted): raise SystemExit('unknown measurement id')
    if a.plan:
        for r in rows: print('%s %s N=%s L=%s ranks=%s threads=%s dims=%s nodes=%s slots=%s'%tuple(r[k] for k in ('measurement_id','mode','n','length','ranks','threads','dims','expected_nodes','expected_slots')))
        return 0
    if a.resolve:
        if a.outcome is None or (a.outcome=='submitted' and not a.job_id) or (a.outcome=='not-found' and a.job_id):
            raise SystemExit('--resolve requires --outcome; --job-id is required only for submitted')
        row=next((r for r in rows if r['measurement_id']==a.resolve),None)
        if row is None: raise SystemExit('unknown measurement id')
        lock=(root/'.submit.lock').open('a+')
        fcntl.flock(lock,fcntl.LOCK_EX)
        state_path=root/'submissions.csv'
        with state_path.open(newline='') as f: states={r['measurement_id']:r for r in csv.DictReader(f)}
        old=states.get(a.resolve)
        if not old or old['state'] not in ('submitting','uncertain','submitted'): raise SystemExit('measurement state cannot be reconciled')
        old.update(state='submitted' if a.outcome=='submitted' else 'not-submitted',
                   job_id=a.job_id or '',note='manually reconciled after bjobs/bhist inspection')
        write_states(state_path,states); print('reconciled %s as %s'%(a.resolve,old['state'])); return 0
    configured=read_cluster_config(Path(__file__).with_name('polus')/'config.sh')
    metadata=json.loads((root/'metadata.json').read_text())
    hosts=metadata.get('allowed_compute_hosts',[])
    if not isinstance(hosts,list) or any(not isinstance(h,str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]*',h) for h in hosts) or len(set(hosts))!=len(hosts):
        raise SystemExit('invalid allowed_compute_hosts')
    use_ib=metadata.get('two_node_transport')=='polus-ucx-rc'
    if use_ib and len(hosts)!=2:
        raise SystemExit('the verified UCX profile requires exactly two allowed compute hosts')
    slots_per_node=int(configured['POLUS_MPI_SLOTS_PER_NODE'])
    if slots_per_node!=int(metadata['protocol']['slots_per_node']):
        raise SystemExit('cluster slots-per-node setting differs from campaign manifest; prepare a new campaign after verifying the cluster')
    if not a.dry_run and len(wanted)>a.max_jobs: raise SystemExit('selection has %d jobs, exceeds --max-jobs=%d'%(len(wanted),a.max_jobs))
    if a.dry_run and a.max_jobs and len(wanted)>a.max_jobs: raise SystemExit('selection has %d jobs, exceeds --max-jobs=%d'%(len(wanted),a.max_jobs))
    total=sum(int(r['expected_slots']) for r in wanted)
    if total>a.max_slots: raise SystemExit('batch requests %d CPU slots, exceeds --max-slots=%d'%(total,a.max_slots))
    if not a.dry_run:
        if not metadata.get('binary_freeze',{}).get('frozen'):
            raise SystemExit('campaign binaries have not been frozen')
        checksums={Path(line.split(None,1)[1]).name:line.split(None,1)[0]
                   for line in (root/'bin'/'SHA256SUMS').read_text().splitlines() if line.strip()}
        for name in ('wave_solver_mpi','wave_solver_opt'):
            digest=hashlib.sha256((root/'bin'/name).read_bytes()).hexdigest()
            if checksums.get(name)!=digest: raise SystemExit('frozen binary checksum mismatch: '+name)
    lock=(root/'.submit.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX)
    state_path=root/'submissions.csv'
    with state_path.open(newline='') as f: states={r['measurement_id']:r for r in csv.DictReader(f)}
    for r in wanted:
        if r['measurement_id'] in states and states[r['measurement_id']]['state'] in ('submitting','submitted','uncertain'):
            raise SystemExit('refusing possible duplicate for %s (%s); reconcile it first'%(r['measurement_id'],states[r['measurement_id']]['state']))
    if not a.dry_run and not os.environ.get('LSB_JOBID') and not os.environ.get('POLUS_SUBMISSION_HOST'):
        raise SystemExit('run on configured submission host; set POLUS_SUBMISSION_HOST only after verifying cluster access')
    template=Path(__file__).with_name('polus')/'mpi_campaign_job.lsf'
    for r in wanted:
        job=root/'jobs'/(r['measurement_id']+'.lsf')
        values=dict(r, campaign=str(root), repo=str(Path(__file__).resolve().parents[1]),
                    slots_per_node=slots_per_node, allowed_compute_hosts=' '.join(hosts),
                    use_ib=int(use_ib and int(r['expected_nodes'])==2))
        content=template.read_text()
        for key,value in values.items(): content=content.replace('@'+key+'@',str(value))
        if re.search(r'@[A-Za-z_]+@',content): raise SystemExit('unexpanded job template value')
        job.write_text(content)
        slots=int(r['expected_slots']); nodes=int(r['expected_nodes'])
        args=['bsub','-q',os.environ.get('MPI_QUEUE',configured['POLUS_FULL_V1_QUEUE']),
              '-W',os.environ.get('MPI_WALLTIME',configured['POLUS_FULL_V1_WALLTIME']),'-x',
              '-n',str(slots),'-R', 'span[hosts=1]' if nodes==1 else 'span[ptile=%d]'%slots_per_node,
              '-J',r['measurement_id'],'-o',str(root/'logs'/(r['measurement_id']+'.%J.out')),
              '-e',str(root/'logs'/(r['measurement_id']+'.%J.err'))]
        hostfile=root/'lsf-hostfiles'/('%sx%s'%(r['ranks'],r['threads']))
        if not hostfile.is_file(): raise SystemExit('missing fixed LSF hostfile')
        del args[6:10]
        args.extend(('-hostfile', str(hostfile)))
        print(('DRY-RUN ' if a.dry_run else '')+' '.join(args)+' < '+str(job),flush=True)
        if a.dry_run: continue
        states[r['measurement_id']]={'measurement_id':r['measurement_id'],'state':'submitting','job_id':'',
                                     'submitted_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'note':'reconcile if interrupted'}
        write_states(state_path,states)
        try:
            result=subprocess.run(args,input=job.read_bytes(),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,check=False)
            output=result.stdout.decode(errors='replace'); print(output,end='')
            match=re.search(r'Job <(\d+)>',output)
            if result.returncode==0 and match:
                states[r['measurement_id']].update(state='submitted',job_id=match.group(1),note='')
            else:
                states[r['measurement_id']].update(state='uncertain',note='bsub response needs manual reconciliation')
            write_states(state_path,states)
            if result.returncode or not match: return 1
        except BaseException:
            states[r['measurement_id']].update(state='uncertain',note='interrupted around bsub; check bjobs/bhist before retry')
            write_states(state_path,states); raise
    return 0

def read_cluster_config(path):
    values={}
    for line in path.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#') or '=' not in line: continue
        key,value=line.split('=',1)
        try: values[key.strip()]=shlex.split(value.strip())[0]
        except IndexError: values[key.strip()]=''
    required=('POLUS_MPI_SLOTS_PER_NODE','POLUS_FULL_V1_QUEUE','POLUS_FULL_V1_WALLTIME')
    missing=[key for key in required if not values.get(key)]
    if missing: raise SystemExit('missing settings in scripts/polus/config.sh: '+', '.join(missing))
    return values

def write_states(path,states):
    temp=path.with_suffix('.csv.tmp')
    with temp.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['measurement_id','state','job_id','submitted_utc','note'])
        w.writeheader(); w.writerows(states.values())
    temp.replace(path)

if __name__=='__main__':
    try: sys.exit(main())
    except (OSError,KeyError,ValueError) as e: sys.exit('error: '+str(e))
