#!/usr/bin/env bash
# Freeze already-built executables and provenance into an empty campaign bin/.
set -euo pipefail
[[ $# == 1 ]] || { echo 'usage: freeze_mpi_campaign.sh CAMPAIGN_DIR' >&2; exit 2; }
campaign=$(cd "$1" && pwd -P)
repo=$(cd "$(dirname "$0")/.." && pwd -P)
[[ -d $campaign/bin && -z $(ls -A "$campaign/bin") ]] || {
  echo 'campaign bin/ must exist and be empty; refusing to overwrite frozen files' >&2; exit 2;
}
for binary in wave_solver_mpi wave_solver_opt; do
  [[ -x "$repo/build/$binary" ]] || { echo "missing executable: build/$binary" >&2; exit 2; }
done
for binary in wave_solver_mpi wave_solver_opt; do
  cp "$repo/build/$binary" "$campaign/bin/$binary"
done
sha256sum "$campaign/bin/wave_solver_mpi" "$campaign/bin/wave_solver_opt" > "$campaign/bin/SHA256SUMS"
{
  printf 'timestamp_utc=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  printf 'hostname=%s\n' "$(hostname -f 2>/dev/null || hostname)"
  printf 'compiler=%s\n' "${CXX:-g++}"
  compiler_info=$("${CXX:-g++}" --version 2>&1)
  printf 'compiler_version=%s\n' "${compiler_info%%$'\n'*}"
  printf 'compiler_flags=%s\n' "${CXXFLAGS:--O2 -Wall -Wextra -Wpedantic}"
  printf 'mpi_wrapper=%s\n' "${MPICXX:-mpicxx}"
  printf 'mpi_wrapper_flags=%s\n' "$("${MPICXX:-mpicxx}" --showme 2>&1 || true)"
  mpi_info=$("${MPIEXEC:-mpirun}" --version 2>&1 || true)
  printf 'mpi_version=%s\n' "${mpi_info%%$'\n'*}"
  printf 'build_commands:\n'
  make -Bn mpi optimized
  cat "$campaign/bin/SHA256SUMS"
} > "$campaign/bin/build-and-runtime.txt"
"${PYTHON:-python3}" - "$campaign/metadata.json" "$campaign/bin/build-and-runtime.txt" <<'PY'
import json,sys
p=sys.argv[1]
with open(p) as f: d=json.load(f)
d['binary_freeze']={'path':'bin/','sha256_file':'bin/SHA256SUMS','runtime_build_metadata':'bin/build-and-runtime.txt','frozen':True}
with open(p+'.tmp','w') as f: json.dump(d,f,indent=2,sort_keys=True); f.write('\n')
import os; os.replace(p+'.tmp',p)
PY
echo "Frozen binaries in $campaign/bin"
