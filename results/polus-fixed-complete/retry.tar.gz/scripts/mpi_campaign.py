#!/usr/bin/env python3
"""Prepare and inspect reproducible MPI/HYBRID campaigns; never submits jobs."""
import argparse
import csv
import itertools
import json
import math
import random
import statistics
import sys
import time
from pathlib import Path

PROTOCOL = {"n": [128, 256, 512], "lengths": [1.0, math.pi], "steps": 20,
            "cfl": 0.5, "repetitions": 10, "mpi_ranks": [1, 4, 8, 16, 32],
            "hybrid_ranks": [1, 2, 4, 8], "hybrid_threads": 4,
            "slots_per_node": 16}
FIELDS = ["measurement_id", "mode", "n", "length", "steps", "final_time",
          "cfl", "ranks", "threads", "dims", "repetition", "expected_nodes",
          "expected_slots", "expected_hosts"]


def dims_for(ranks):
    # Deterministic, balanced topology; distribute prime factors to the
    # currently shortest axis, then order axes to match the documented grids.
    known = {1: (1, 1, 1), 2: (2, 1, 1), 4: (2, 2, 1), 8: (2, 2, 2),
             16: (4, 2, 2), 32: (4, 4, 2)}
    if ranks not in known:
        raise ValueError("unsupported rank count")
    return "x".join(map(str, known[ranks]))


def rows(seed):
    configs = []
    for n, length in itertools.product(PROTOCOL["n"], PROTOCOL["lengths"]):
        for mode, ranks, threads in ([('mpi', p, 1) for p in PROTOCOL['mpi_ranks']] +
                                     [('hybrid', p, 4) for p in PROTOCOL['hybrid_ranks']]):
            factor = math.sqrt(3 * (n / length) ** 2)
            final_time = PROTOCOL['steps'] * PROTOCOL['cfl'] / factor
            slots = ranks * threads
            nodes = int(math.ceil(slots / float(PROTOCOL['slots_per_node'])))
            configs.append(dict(mode=mode, n=n, length=length, steps=20,
                final_time=format(final_time, '.17g'), cfl=0.5, ranks=ranks,
                threads=threads, dims=dims_for(ranks), expected_nodes=nodes,
                expected_slots=slots, expected_hosts=nodes))
    rng = random.Random(seed)
    result = []
    for rep in range(1, 11):
        order = list(configs)
        rng.shuffle(order)
        for config in order:
            row = dict(config, repetition=rep,
                       measurement_id='%s-n%d-l%s-r%d-t%d-rep%02d' % (
                           config['mode'], config['n'],
                           '1' if config['length']==1.0 else 'pi',
                           config['ranks'], config['threads'], rep))
            result.append(row)
    return result


def prepare(root, seed):
    root = Path(root)
    root.mkdir(parents=True, exist_ok=False)
    for name in ('bin', 'jobs', 'logs', 'measurements', 'analysis'):
        (root / name).mkdir()
    manifest = rows(seed)
    with (root / 'manifest.csv').open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=FIELDS); w.writeheader(); w.writerows(manifest)
    metadata = {"schema_version": 1, "created_utc": time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
      "seed": seed, "protocol": PROTOCOL,
      "protocol_note": "N is intervals per axis; lengths are cubic domain lengths.",
      "binary_freezing": "Copy executables to bin/, record sha256sum, compiler/MPI versions and flags in metadata.json before jobs.",
      "campaign_status": "prepared; not submitted", "manifest_rows": len(manifest)}
    (root / 'metadata.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    with (root / 'submissions.csv').open('w', newline='') as f:
        fields=['measurement_id','state','job_id','submitted_utc','note']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        w.writerows({'measurement_id':r['measurement_id'],'state':'pending','job_id':'',
                     'submitted_utc':'','note':''} for r in manifest)
    # Configuration hashes help freeze provenance without claiming binaries exist.
    (root / 'jobs' / 'README.txt').write_text(
        'Generated row descriptors belong here. Scheduler scripts must verify allocation at runtime.\n')
    print('campaign=%s rows=%d seed=%d' % (root.resolve(), len(manifest), seed))


def load_manifest(path):
    with Path(path).open(newline='') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            raise ValueError('manifest header does not match schema')
        return list(reader)


def expected_error(n, length, steps):
    theta = 2 * math.asin(0.5 * math.sin(math.pi / (2*n)))
    peak = math.sin(math.pi * (n//2) / n) ** 3
    # Discrete and continuous amplitudes for T derived from the fixed CFL protocol.
    t = steps * 0.5 / math.sqrt(3 * (n / length) ** 2)
    exact = math.cos(math.pi * math.sqrt(3) * t / length)
    return peak * abs(math.cos(steps * theta) - exact)


def analyze(campaign):
    root=Path(campaign); manifest=load_manifest(root/'manifest.csv')
    ids=[r['measurement_id'] for r in manifest]
    issues=[]
    if len(ids)!=len(set(ids)): issues.append('duplicate measurement IDs in manifest')
    for r in manifest:
        try:
            ranks=int(r['ranks']); threads=int(r['threads']); n=int(r['n'])
            dims=tuple(int(x) for x in r['dims'].split('x'))
            allowed=(r['mode']=='mpi' and ranks in (1,4,8,16,32) and threads==1) or (
                    r['mode']=='hybrid' and ranks in (1,2,4,8) and threads==4)
            length=float(r['length']); slots=ranks*threads
            valid_time=abs(float(r['final_time'])-20*0.5/math.sqrt(3*(n/length)**2))<1e-14
            expected_grid=tuple(map(int,dims_for(ranks).split('x')))
            if not allowed or n not in (128,256,512) or length not in (1.0,math.pi) or \
                    len(dims)!=3 or dims[0]*dims[1]*dims[2]!=ranks or sorted(dims)!=sorted(expected_grid) or \
                    slots!=int(r['expected_slots']) or int(r['expected_nodes'])!=math.ceil(slots/float(PROTOCOL['slots_per_node'])) or \
                    int(r['steps'])!=20 or float(r['cfl'])!=0.5 or not valid_time or \
                    int(r['repetition']) not in range(1,11):
                issues.append('invalid parameter combination in manifest: '+r['measurement_id'])
        except (ValueError,KeyError,ZeroDivisionError):
            issues.append('malformed manifest row: '+r.get('measurement_id','?'))
    records={}; duplicates=set()
    for p in (root/'measurements').glob('*.csv'):
        try:
            with p.open(newline='') as f:
                for row in csv.DictReader(f):
                    mid=row.get('measurement_id','')
                    if mid in records:
                        issues.append('duplicate measurement result: '+mid); duplicates.add(mid)
                    records[mid]=row
        except (OSError,csv.Error) as ex:
            issues.append('malformed measurement file %s: %s'%(p.name,ex))
    exp={r['measurement_id']:r for r in manifest}
    for mid in records.keys()-exp.keys(): issues.append('unexpected measurement: '+mid)
    valid=[]; valid_ids=set()
    for mid, e in exp.items():
        if mid in duplicates: continue
        r=records.get(mid)
        if not r: issues.append('missing measurement: '+mid); continue
        if r.get('status')!='passed': issues.append('failed execution: '+mid); continue
        try:
            elapsed=float(r['solve_wall_seconds']); err=float(r['max_absolute_error'])
            n=int(e['n']); length=float(e['length']); steps=int(e['steps'])
            if not math.isfinite(elapsed) or elapsed<=0 or not math.isfinite(err) or err<0: raise ValueError('malformed numeric value')
            for key in ('mode','n','steps','ranks','threads','dims'):
                if str(r.get(key,'')) != str(e[key]): raise ValueError('mismatch '+key)
            for key in ('expected_slots','expected_nodes'):
                if str(r.get(key,'')) != str(e[key]): raise ValueError('mismatch '+key)
            if int(r['actual_nodes'])!=int(e['expected_nodes']) or int(r['actual_slots'])!=int(e['expected_slots']):
                raise ValueError('actual scheduler allocation mismatch')
            rank_hosts=[h for h in r['hosts'].split(',') if h]
            if len(rank_hosts)!=int(e['ranks']) or len(set(rank_hosts))!=int(e['expected_nodes']):
                raise ValueError('actual MPI host placement mismatch')
            actual_length=float(r['length'])
            if not math.isfinite(actual_length) or abs(actual_length-float(e['length']))>1e-14: raise ValueError('mismatch length')
            actual_time=float(r['final_time'])
            if not math.isfinite(actual_time) or abs(actual_time-float(e['final_time'])) > 1e-12*max(1,abs(float(e['final_time']))):
                raise ValueError('mismatch final_time')
            if r.get('boundary_check')!='passed': raise ValueError('incomplete solver output')
            tol=8*sys.float_info.epsilon*(steps+1)**2
            if abs(err-expected_error(n,length,steps)) > tol: raise ValueError('incorrect numerical error')
            valid.append((e,elapsed)); valid_ids.add(mid)
        except (KeyError,ValueError,OverflowError) as ex:
            issues.append('invalid measurement %s: %s' % (mid, ex or 'malformed numeric value'))
    # Validate expected configuration and mandatory one-rank mode baselines.
    if len(manifest)!=540: issues.append('manifest has %d rows, expected 540' % len(manifest))
    for mode, ranks, threads in [('mpi',1,1),('hybrid',1,4)]:
        for n,l in itertools.product((128,256,512),(1.0,math.pi)):
            if not any(r['mode']==mode and int(r['ranks'])==ranks and int(r['threads'])==threads and
                       int(r['n'])==n and abs(float(r['length'])-l)<1e-14 for r in manifest):
                issues.append('missing one-rank baseline configuration: %s N=%d L=%s' %(mode,n,l))
            baseline_ids={r['measurement_id'] for r in manifest if r['mode']==mode and
                          int(r['ranks'])==1 and int(r['threads'])==threads and int(r['n'])==n and
                          abs(float(r['length'])-l)<1e-14}
            if not baseline_ids.intersection(valid_ids):
                issues.append('missing valid one-rank reference measurements: %s N=%d L=%s' %(mode,n,l))
    groups={}
    for e,t in valid:
        key=(e['mode'],e['n'],e['length'],e['ranks'],e['threads'],e['dims'],e['expected_nodes'])
        groups.setdefault(key,[]).append((e,t))
    output=[]
    for key,items in sorted(groups.items()):
        ts=[t for _,t in items]; mode,n,l,ranks,threads,dims,nodes=key
        baseline_key=(mode,n,l,'1','1' if mode=='mpi' else '4',dims_for(1),'1')
        baseline=groups.get(baseline_key)
        speed=1.0 if int(ranks)==1 else (
            statistics.median(t for _,t in baseline)/statistics.median(ts) if baseline else '')
        output.append({'mode':mode,'n':n,'length':l,'ranks':ranks,'threads':threads,'dims':dims,'expected_nodes':nodes,
           'valid_repetitions':len(ts),'min_seconds':min(ts),'max_seconds':max(ts),
           'mean_seconds':statistics.mean(ts),'median_seconds':statistics.median(ts),
           'sample_stddev':statistics.stdev(ts) if len(ts)>1 else '',
           'coefficient_variation':statistics.stdev(ts)/statistics.mean(ts) if len(ts)>1 else '',
           'speedup':speed, 'efficiency':speed/float(ranks) if speed!='' else ''})
    (root/'analysis'/'summary.csv').parent.mkdir(exist_ok=True)
    with (root/'analysis'/'summary.csv').open('w',newline='') as f:
        fields=list(output[0]) if output else ['mode','n','length','ranks','threads','dims','valid_repetitions']
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(output)
    complete=not issues and len(valid)==len(manifest)
    report=['campaign_status='+('complete' if complete else 'incomplete'),
            'expected=%d valid=%d'%(len(manifest),len(valid)), 'issues=%d'%len(issues)] + issues
    (root/'analysis'/'validation.txt').write_text('\n'.join(report)+'\n')
    print('\n'.join(report))
    return 0 if complete else 1


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('prepare'); q.add_argument('directory'); q.add_argument('--seed',type=int,default=20261114)
    q=sub.add_parser('analyze'); q.add_argument('campaign')
    q=sub.add_parser('plan'); q.add_argument('campaign')
    a=p.parse_args()
    if a.cmd=='prepare': prepare(a.directory,a.seed); return 0
    if a.cmd=='analyze': return analyze(a.campaign)
    rows_=load_manifest(Path(a.campaign)/'manifest.csv')
    for r in rows_: print(','.join(r[k] for k in ('measurement_id','mode','n','length','ranks','threads','dims','expected_nodes','expected_slots')))
    return 0

if __name__=='__main__':
    try: sys.exit(main())
    except (OSError,ValueError) as e: sys.exit('error: '+str(e))
