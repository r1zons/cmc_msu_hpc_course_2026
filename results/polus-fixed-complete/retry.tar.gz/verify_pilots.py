import csv,re,sys,collections,math
from pathlib import Path
p=Path('campaign')
def read(path):
 with path.open(newline='') as f:return list(csv.DictReader(f))
wanted=set((p/'pilot-ids.txt').read_text().strip().split(','))
manifest={r['measurement_id']:r for r in read(p/'manifest.csv')}
passed=0
for j in read(p/'submissions.csv'):
 i=j['measurement_id']
 if i not in wanted: continue
 m=manifest[i]; r,t=int(m['ranks']),int(m['threads']); stem=i+'.'+j['job_id']
 out=p/'logs'/(stem+'.out')
 if not out.exists(): print(i,'waiting');continue
 if 'Successfully completed' not in out.read_text(errors='replace'): print(i,'FAIL', (p/'logs'/(stem+'.err')).read_text(errors='replace')[-350:]);continue
 expected={}
 for line in (p/'rankfiles'/f'{r}x{t}').read_text().splitlines():
  rank,host,s,a,b=re.fullmatch(r'rank (\d+)=(\S+) slot=(\d+):(\d+)-(\d+)',line).groups()
  expected[int(rank)]=(host,{(int(s),int(s)*10+k) for k in range(int(a),int(b)+1)})
 actual={}
 for line in (p/'logs'/(stem+'.err')).read_text(errors='replace').splitlines():
  match=re.search(r'^\[([^:]+):\d+\] MCW rank (\d+) bound to (.*)',line)
  if match:
   host,rank,mask=match.groups()
   actual[int(rank)]=(host,{tuple(map(int,x)) for x in re.findall(r'socket (\d+)\[core (\d+)\[hwt',mask)})
 try:
  assert actual==expected, (expected,actual)
  cores=[(h,c) for h,k in actual.values() for c in k]
  assert len(cores)==len(set(cores))==r*t
  result,=read(p/'measurements'/(stem+'.csv'))
  assert result['job_id']==j['job_id'] and result['boundary_check']=='passed' and result['status']=='passed'
  assert result['mpi_ranks']==str(r) and result['openmp_threads']==str(t)
  assert result['process_grid']==m['dims'] and result['actual_slots']==m['expected_slots']
  assert abs(float(result['max_absolute_error'])-1.1226404146302826e-6)<8e-13
 except (AssertionError,ValueError,OSError) as error: print(i,'FAIL',error);continue
 print(i,j['job_id'],'PASS');passed+=1
print(f'{passed}/16 passed')
sys.exit(passed!=16)
