Generated row descriptors belong here. Scheduler scripts must verify allocation at runtime.
